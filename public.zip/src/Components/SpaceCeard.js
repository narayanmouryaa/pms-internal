// import * as React from 'react';
// import Card from '@mui/material/Card';
// import CardContent from '@mui/material/CardContent';
// import Container from '@mui/material/Container';
// import Input from '@mui/material/Input';
// import InputLabel from '@mui/material/InputLabel';
// import FormControl from '@mui/material/FormControl';
// import InputAdornment from '@mui/material/InputAdornment';
// import { Box, Typography,Button } from '@mui/material';
// import Radio from '@mui/material/Radio';
// import RadioGroup from '@mui/material/RadioGroup';
// import FormControlLabel from '@mui/material/FormControlLabel';


// export default function SpaceCard() {

  
//   return (
//     <>
    
//           <Container style={{ display: 'flex', justifyContent: 'center' }} >
//         <Card sx={{ minWidth: 275 }} style={{ width: '750px', height: '600px', padding: '20px' }}>
//           <CardContent>
//             <Typography sx={{ fontSize: 40, fontWeight: 600 }} >
//               Create New Space
//             </Typography>
//             <Typography sx={{ fontSize: 14 }} component="div">
//               Clarity gives you the blocks and components you need to create <br /> a truly professional website.
//             </Typography>


//             <Box mt={4}>
              
//               <FormControl variant="standard" >
//                 <InputLabel htmlFor="input-with-icon-adornment" style={{ fontWeight: "600", fontSize: '18px' }}>
//                   Space Name
//                 </InputLabel>
//                 <Input

//                   id="input-with-icon-adornment"
//                   placeholder="Enter Space Name"
//                   type='text'
//                   startAdornment={
//                     <InputAdornment position="start" style={{ width: '250px' }}>

//                     </InputAdornment>
//                   }
//                 />
//               </FormControl>
//             </Box>


//             <Box mt={3}>
              
//               <FormControl variant="standard" >
//                 <InputLabel htmlFor="input-with-icon-adornment" style={{ fontWeight: "600", fontSize: '18px' }}>
//                   Space Color
//                 </InputLabel>
//                 <Input
//                   id="input-with-icon-adornment"
//                   placeholder="Enter Space Color Code"
//                   type='text'
//                   startAdornment={
//                     <InputAdornment position="start" style={{ width: '250px' }}>

//                     </InputAdornment>
//                   }
//                 />
//               </FormControl>
//             </Box>



//             <Box mt={3}>
              
//               <FormControl variant="standard" >
//                 <InputLabel htmlFor="input-with-icon-adornment" style={{ fontWeight: "600", fontSize: '18px' }}>
//                   Space Icon
//                 </InputLabel>
//                 <Input
//                   id="input-with-icon-adornment"
//                   placeholder="Upload Space icon"
//                   type='email'
//                   startAdornment={
//                     <InputAdornment position="start" style={{ width: '250px' }}>

//                     </InputAdornment>
//                   }
//                 />
//               </FormControl>
//             </Box>

//             <FormControl>

//               <RadioGroup
//                 row
//                 aria-labelledby="demo-row-radio-buttons-group-label"
//                 name="row-radio-buttons-group"
//                 style={{ marginTop: '25px' }}
//               >
//                 <Typography style={{ paddingTop: '7px', paddingRight: '25px' }}>Share Arvindtest</Typography>
//                 <FormControlLabel value="Workspace" control={<Radio />} label="AKM Workspace" />
//                 <FormControlLabel value="private" control={<Radio />} label="Private" />


//               </RadioGroup>
//             </FormControl>


//             <Box mt={3}>
              
//               <FormControl variant="standard" >
//                 <InputLabel htmlFor="input-with-icon-adornment" style={{ fontWeight: "600", fontSize: '18px' }}>
//                   Space Color
//                 </InputLabel>
//                 <Input
//                   id="input-with-icon-adornment"
//                   placeholder="Enter Space Color Code"
//                   type='text'
//                   startAdornment={
//                     <InputAdornment position="start" style={{ width: '420px' }}>

//                     </InputAdornment>
//                   }
//                 />
//               </FormControl>
//             </Box>
            

//           </CardContent>
//           <Button variant='contained' style={{width:'650px',textAlign:"center"}}>Next</Button>
//         </Card>
//       </Container>   
        
//         </>
//   );
// }



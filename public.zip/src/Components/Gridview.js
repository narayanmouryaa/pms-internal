import React from 'react';
// import  Typography  from '@mui/material/Typography';
import NavbarFixed from './NavBar';
import ResponsiveDrawer from "./Fixedsidenav";
// import Container from '@mui/material/Container';

// import * as React from 'react';
import { styled } from '@mui/material/styles';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';

// import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
// import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import Form from 'react-bootstrap/Form';
// import {Container,Row,Col} from '@mui/material';


const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: 'center',
  color: theme.palette.text.secondary,
}));



const Gridview = () => {
  return (
    <>
      <NavbarFixed />

      <ResponsiveDrawer />

      <Box>
        <Form>  <Form.Control
          style={{ padding: '5px' }}
          type="search"
          placeholder="Search"
          className="me-2"
          aria-label="Search"
        />
        </Form>

      </Box>

      {/* <Container>
              <Row>
                <Col>
                
                </Col>
              </Row>
            </Container>
             */}





      <Box sx={{ flexGrow: 1 }} style={{ padding: '5px' }}>
        <Grid container spacing={2}>

          <Grid item xs={3}>


          </Grid>

          <Grid item xs={3}>

            <Item style={{ backgroundColor: 'lightGray' }}>
              <Typography style={{ display: 'flex', justifyContent: 'start', fontWeight: '600', padding: '8px' }} >TO DO</Typography>
              <Card sx={{ minWidth: 275, borderRadius: '10px' }}  >
                <CardContent>
                  <Typography sx={{ fontSize: 16, textAlign: 'start' }} gutterBottom>
                    As a translator,I want integrate Crowdin webhook to notify translators about changed strings
                  </Typography>
                </CardContent>
                <CardActions>
                  {/* <Button size="small">Learn More</Button> */}
                </CardActions>
              </Card>


              <Card sx={{ minWidth: 275, borderRadius: '10px', marginTop: '10px' }}  >
                <CardContent>
                  <Typography sx={{ fontSize: 16, textAlign: 'start' }} gutterBottom>
                    As a translator,I want integrate Crowdin webhook to notify.
                  </Typography>
                </CardContent>
                <CardActions>
                  {/* <Button size="small">Learn More</Button> */}
                </CardActions>
              </Card>

              <Card sx={{ minWidth: 275, borderRadius: '10px', marginTop: '10px' }}  >
                <CardContent>
                  <Typography sx={{ fontSize: 16, textAlign: 'start' }} gutterBottom>
                    As a translator,I want integrate Crowdin webhook to notify.
                  </Typography>
                </CardContent>
                <CardActions>
                  {/* <Button size="small">Learn More</Button> */}
                </CardActions>
              </Card>
            </Item>

          </Grid>
          <Grid item xs={3}>
            <Item style={{ backgroundColor: 'lightGray' }}>
              <Typography style={{ display: 'flex', justifyContent: 'start', fontWeight: '600', padding: '8px' }} >IN PROGRESS</Typography>
              <Card sx={{ minWidth: 275, borderRadius: '10px' }}  >
                <CardContent>
                  <Typography sx={{ fontSize: 16, textAlign: 'start' }} gutterBottom>
                    As a translator,I want integrate Crowdin webhook to notify translators about changed strings
                  </Typography>
                </CardContent>
                <CardActions>
                  {/* <Button size="small">Learn More</Button> */}
                </CardActions>
              </Card>


              <Card sx={{ minWidth: 275, borderRadius: '10px', marginTop: '10px' }}  >
                <CardContent>
                  <Typography sx={{ fontSize: 16, textAlign: 'start' }} gutterBottom>
                    As a translator,I want integrate Crowdin webhook to notify.
                  </Typography>
                </CardContent>
                <CardActions>
                  {/* <Button size="small">Learn More</Button> */}
                </CardActions>
              </Card>

              <Card sx={{ minWidth: 275, borderRadius: '10px', marginTop: '10px' }}  >
                <CardContent>
                  <Typography sx={{ fontSize: 16, textAlign: 'start' }} gutterBottom>
                    As a translator,I want integrate Crowdin webhook to notify.
                  </Typography>
                </CardContent>
                <CardActions>
                  {/* <Button size="small">Learn More</Button> */}
                </CardActions>
              </Card>


              <Card sx={{ minWidth: 275, borderRadius: '10px', marginTop: '10px' }}  >
                <CardContent>
                  <Typography sx={{ fontSize: 16, textAlign: 'start' }} gutterBottom>
                    As a translator,I want integrate Crowdin webhook to notify.
                  </Typography>
                </CardContent>
                <CardActions>
                  {/* <Button size="small">Learn More</Button> */}
                </CardActions>
              </Card>
            </Item>
          </Grid>
          <Grid item xs={3}>
            <Item style={{ backgroundColor: 'lightGray' }}>
              <Typography style={{ display: 'flex', justifyContent: 'start', fontWeight: '600', padding: '8px' }} >DONE</Typography>
              <Card sx={{ minWidth: 275, borderRadius: '10px' }}  >
                <CardContent>
                  <Typography sx={{ fontSize: 16, textAlign: 'start' }} gutterBottom>
                    As a translator,I want integrate Crowdin webhook to notify translators about changed strings
                  </Typography>
                </CardContent>
                <CardActions>
                  {/* <Button size="small">Learn More</Button> */}
                </CardActions>
              </Card>


              <Card sx={{ minWidth: 275, borderRadius: '10px', marginTop: '10px' }}  >
                <CardContent>
                  <Typography sx={{ fontSize: 16, textAlign: 'start' }} gutterBottom>
                    As a translator,I want integrate Crowdin webhook to notify.
                  </Typography>
                </CardContent>
                <CardActions>
                  {/* <Button size="small">Learn More</Button> */}
                </CardActions>
              </Card>

              <Card sx={{ minWidth: 275, borderRadius: '10px', marginTop: '10px' }}  >
                <CardContent>
                  <Typography sx={{ fontSize: 16, textAlign: 'start' }} gutterBottom>
                    As a translator,I want integrate Crowdin webhook to notify.
                  </Typography>
                </CardContent>
                <CardActions>
                  {/* <Button size="small">Learn More</Button> */}
                </CardActions>
              </Card>
            </Item>
          </Grid>

        </Grid>
      </Box>





    </>
  );
};

export default Gridview;

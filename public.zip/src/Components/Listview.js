import React from 'react';
import  Typography  from '@mui/material/Typography';
import NavbarFixed from './NavBar';
import ResponsiveDrawer from "./Fixedsidenav";
import Container from '@mui/material/Container';
import SwipeableTemporaryDrawer from './Pesistentleft';



const Listview = () => {
    return (
    <>
      <NavbarFixed />
      <SwipeableTemporaryDrawer/>
      <ResponsiveDrawer />
      <Container style={{ display: 'flex', justifyContent: 'start',alignItems:'flex-start' }}>
      <Typography variant='h6' style={{fontWeight:'600'}}>Hey Mariana-</Typography>
      <Typography paragraph>here's what's happening with your today</Typography>
       
      </Container >


    </>
  );
};

export default Listview;

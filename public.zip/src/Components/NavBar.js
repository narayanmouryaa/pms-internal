import Container from 'react-bootstrap/Container';
import Form from 'react-bootstrap/Form';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import AppsIcon from '@mui/icons-material/Apps';
import ListIcon from '@mui/icons-material/List';
import ViewQuiltIcon from '@mui/icons-material/ViewQuilt';
import NotificationsIcon from '@mui/icons-material/Notifications';
import SettingsIcon from '@mui/icons-material/Settings';
import Avatar from '@mui/material/Avatar';
// import SearchIcon from '@mui/icons-material/Search';
import Button from '@mui/material/Button';



function NavbarFixed() {
    return (

        <>
            <Navbar bg="light" expand="lg" >
                <Container fluid>
                    <AppsIcon  />
                    <Navbar.Brand href="#" style={{ fontWeight: "600" }}> Project Management System</Navbar.Brand>
                    <Navbar.Toggle aria-controls="navbarScroll" />
                    <Navbar.Collapse id="navbarScroll">
                        <Nav
                            className="me-auto my-2 my-lg-0"
                            style={{ maxHeight: '100px' }}
                            navbarScroll
                        >


                            <Button >
                                <Nav.Link href="Listview" style={{ marginLeft: '40px' }}><ListIcon />List view </Nav.Link>
                            </Button>
                            <Button>

                                <Nav.Link href="Gridview"><ViewQuiltIcon /> Grid view </Nav.Link>
                            </Button>
                        </Nav>
                        <Form className="d-flex">
                            <Form.Control
                                style={{ padding: '5px' }}
                                type="search"
                                placeholder="Search"
                                className="me-2"
                                aria-label="Search"

                            />

                            <Nav.Link href="#" style={{ margin: "5px" }}><NotificationsIcon /></Nav.Link>
                            <Nav.Link href="settings" style={{ margin: "5px" }}><SettingsIcon /> </Nav.Link>
                            <Avatar style={{ margin: "5px" }} src='/Images/man1.jpg'></Avatar>

                        </Form>
                    </Navbar.Collapse>
                </Container>
            </Navbar>

        </>

    );
}

export default NavbarFixed;
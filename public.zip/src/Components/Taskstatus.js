import * as React from 'react';
// import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import Modal from '@mui/material/Modal';
// import AddIcon from '@mui/icons-material/Add';


// import * as React from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
// import Container from '@mui/material/Container';
// import Input from '@mui/material/Input';
// import InputLabel from '@mui/material/InputLabel';
// import FormControl from '@mui/material/FormControl';
// import InputAdornment from '@mui/material/InputAdornment';
// import Button  from '@mui/material';
// import Radio from '@mui/material/Radio';
// import RadioGroup from '@mui/material/RadioGroup';
// import FormControlLabel from '@mui/material/FormControlLabel';
import { TextField, Container } from '@mui/material';

// import IconButton from '@mui/material/IconButton';
// import CloseIcon from '@mui/icons-material/Close';
import AddIcon from '@mui/icons-material/Add';
import Row from 'react-bootstrap/Row';






const style = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 750,
  bgcolor: 'background.paper',
  //   border: '2px solid #000',
  borderRadius: "10px",
  boxShadow: 24,
  p: 4,
};




export default function TaskStatus() {
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);



  return (
    <div>
      <Button onClick={handleOpen}>+</Button>
      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >

        <Container style={{ display: 'flex', justifyContent: 'center' }} >
          <Card sx={style} >
            <CardContent>
              <Typography sx={{ fontSize: 35, fontWeight: 600 }} >
                What task Status do you want ?
              </Typography>



              <Container>
                <Row >
                  <Typography sx={{ fontSize: 20 }} gutterBottom>
                    Active Status
                  </Typography>
                  <Typography> Status name </Typography>
                  <TextField
                    variant='outlined'
                    style={{ width: '450px' }}
                  />
                  <Typography> Status color</Typography>
                  <TextField
                    variant='outlined'
                    style={{ width: '200px' }}
                  />

                  <AddIcon />
                </Row>

              </Container>




              {/* 
                <Box style={{display:'inline-block'}}>
                    <Typography sx={{fontSize:20}} gutterBottom>
                        Active Status
                    </Typography>
                    <Typography> Status name </Typography>
                    <TextField
                    variant='outlined'
                    style={{width:'450px'}}
                    />
                    <Typography> Status color</Typography>
                    <TextField
                    variant='outlined'
                    style={{width:'200px'}}
                    />
                    
                    <AddIcon/>   


                </Box> */}


              {/* <Box mt={4}>

                  <FormControl variant="standard" >
                  <InputLabel htmlFor="input-with-icon-adornment" style={{ fontWeight: "600", fontSize: '22px',marginBottom:'10px' }}>
                     Active Statuses
                    </InputLabel>
                    <InputLabel htmlFor="input-with-icon-adornment" style={{ fontWeight: "600", fontSize: '18px' }}>
                      Status Name
                    </InputLabel>
                    
                  </FormControl>
                </Box> */}


              {/* <Box mt={5}>

                  <FormControl variant="standard" >
                    <InputLabel htmlFor="input-with-icon-adornment" style={{ fontWeight: "600", fontSize: '18px' }}>
                      List description
                    </InputLabel>
                    <Input
                      id="input-with-icon-adornment"
                      placeholder="Describe your list here"
                      type='text'
                      startAdornment={
                        <InputAdornment position="start" style={{ width: '250px' }}>

                        </InputAdornment>
                      }
                    />
                  </FormControl>
                </Box> */}



              {/* <Box mt={3}>

                  <FormControl variant="standard" >
                    <InputLabel htmlFor="input-with-icon-adornment" style={{ fontWeight: "600", fontSize: '18px' }}>
                      Attachments
                    </InputLabel>
                    <Input
                      id="input-with-icon-adornment"
                      placeholder="Upload your attachment"
                      type='email'
                      startAdornment={
                        <InputAdornment position="start" style={{ width: '250px' }}>

                        </InputAdornment>
                      }
                    />
                  </FormControl>
                </Box> */}

              {/* <FormControl>

                  <RadioGroup
                    row
                    aria-labelledby="demo-row-radio-buttons-group-label"
                    name="row-radio-buttons-group"
                    style={{ marginTop: '25px' }}
                  >
                    <Typography style={{ paddingTop: '7px', paddingRight: '25px' }}>Share List With</Typography>
                    <FormControlLabel value="Workspace" control={<Radio />} label="AKM Workspace" />
                    <FormControlLabel value="private" control={<Radio />} label="Private" />


                  </RadioGroup>
                </FormControl> */}


              {/* <Box mt={3}>

                  <FormControl variant="standard" >
                    <InputLabel htmlFor="input-with-icon-adornment" style={{ fontWeight: "600", fontSize: '18px' }}>
                      Space Color
                    </InputLabel>
                    <Input
                      id="input-with-icon-adornment"
                      placeholder="Enter Space Color Code"
                      type='text'
                      startAdornment={
                        <InputAdornment position="start" style={{ width: '420px' }}>

                        </InputAdornment>
                      }
                    />
                  </FormControl>
                </Box> */}


            </CardContent>
            <Button variant='contained' style={{ width: '650px', textAlign: "center" }}>Next</Button>
          </Card>
        </Container>
      </Modal>
    </div>
  );
}

import ResponsiveDrawer from "./Fixedsidenav";
// import PersistentDrawerLeft from "./Pesistentleft";
import * as React from 'react';
import NavbarFixed from "./NavBar";
import { Container, Row, Col } from "react-bootstrap";
// import Grid from '@mui/material/Unstable_Grid2';
import SwipeableTemporaryDrawer from './Pesistentleft';
import TaskStatus from './Taskstatus';



function Mainpage() {

  return (
    <>
      <Container fluid>
        <Row>
          <Col md={12}>
            <NavbarFixed />
          </Col>
        </Row>
        <Row>
          <Col md={4}>
             < ResponsiveDrawer />
             </Col> 
            <SwipeableTemporaryDrawer/>
        </Row> 
        {/* <CustomizedDialogs/> */}
        <TaskStatus/>
   

      </Container>
    </>
  )
}

export default Mainpage;
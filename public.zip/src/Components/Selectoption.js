import * as React from 'react';
import Button from '@mui/material/Button';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import { Divider } from '@mui/material';

import FormatListBulletedIcon from '@mui/icons-material/FormatListBulleted';
import FolderCopyIcon from '@mui/icons-material/FolderCopy';
// import CustomizedDialogs  from './Closecreatelist'
import Nav from 'react-bootstrap/Nav';




export default function BasicMenu() {
   
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <div>
      <Button
        id="basic-button"
        aria-controls={open ? 'basic-menu' : undefined}
        aria-haspopup="true"
        aria-expanded={open ? 'true' : undefined}
        onClick={handleClick}
      >
        +
      </Button>
      <Menu
        id="basic-menu"
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        MenuListProps={{
          'aria-labelledby': 'basic-button',
        }}
      >
       
        <MenuItem onClick={handleClose} style={{width:'200px'}} ><FormatListBulletedIcon/>
        <Nav.Link href="Createlist" style={{ marginLeft: '40px' }}> List  </Nav.Link>
              </MenuItem>
        <Divider/>
        <MenuItem onClick={handleClose } style={{width:'200px'}}>
             <FolderCopyIcon/><Nav.Link href="Createfolder" style={{ marginLeft: '40px' }}>  Folder </Nav.Link> 
             </MenuItem>
        <Divider/>
        {/* <MenuItem onClick={handleClose}>Logout</MenuItem> */}
      </Menu>
    </div>
  );
}
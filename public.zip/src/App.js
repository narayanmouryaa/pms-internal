/* eslint-disable react/jsx-no-undef */
// import './App.css';
import BasicCard from './Components/system';
import NavScrollExample from "./Components/NavBar";
import 'bootstrap/dist/css/bootstrap.min.css';
import Fifthpage from './Components/fifthpage';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import SettingPage from './Components/settings';
// import  ResponsiveDrawer from "./Components/Fixedsidenav";
// import PersistentDrawerLeft from "./Components/Pesistentleft";
// import  NavbarFixed from "./NavBar";
import Mainpage from './Components/Mainpage';
import Listview from './Components/Listview';
import Gridview from './Components/Gridview';
import SpaceCard from './Components/Spacecard';
import CustomizedDialogs from './Components/Closecreatelist';
import Folder from './Components/Closefolder';
import { Col, Row } from 'react-bootstrap';
import NavbarFixed from './Components/NavBar';
import ResponsiveDrawer from './Components/Fixedsidenav';
import SwipeableTemporaryDrawer from './Components/Pesistentleft';

function App() {
  return (
    <>
      {/* <Row>
        <Col md={12}>
          <NavbarFixed />
        </Col>
      </Row>
      < ResponsiveDrawer />
      <SwipeableTemporaryDrawer /> */}
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Mainpage />} />
          <Route path="Listview" element={<Listview />}></Route>
          <Route path="Gridview" element={<Gridview />}></Route>
          {/* <Route index element={<ResponsiveDrawer  />} ></Route>*/}
          {/* <Route path="*" element={<PersistentDrawerLeft/>}> </Route> */}
          <Route path="settings" element={<SettingPage />}></Route>
          <Route path="/" element={<NavScrollExample />} />
          <Route path="blogs" element={<Fifthpage />}></Route>
          <Route path="drawer" element={<BasicCard />}></Route>
          <Route path="spacecard" element={<SpaceCard />}></Route>
          <Route path="Createlist" element={<CustomizedDialogs />}></Route>
          <Route path="Createfolder" element={<Folder />}></Route>
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;